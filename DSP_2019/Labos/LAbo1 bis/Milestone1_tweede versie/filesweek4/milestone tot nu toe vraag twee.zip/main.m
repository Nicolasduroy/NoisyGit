% Exercise session 4: DMT-OFDM transmission scheme

% Convert BMP image to bitstream
[bitStream, imageData, colorMap, imageSize, bitsPerPixel] = imagetobitstream('image.bmp');

% QAM modulation
Nq = 4;
M = 2^Nq;
qamStream = qam_mod(bitStream, M);

% OFDM modulation
P = 3;  % Amount of carriers
lengthqam = length(bitStream)/Nq;
L = 50; % Length of channel-impulseresponse
ofdmStream = ofdm_mod(qamStream, P, lengthqam, L);

% Channel
SNR = 50;
rxOfdmStream = awgn(ofdmStream, SNR);

% OFDM demodulation
rxQamStream = ofdm_demod(rxOfdmStream, P, lengthqam, L);

% QAM demodulation
rxBitStream = qam_demod(rxQamStream, M);

% Compute BER
berTransmission = ber(bitStream,rxBitStream);

% Construct image from bitstream
imageRx = bitstreamtoimage(rxBitStream, imageSize, bitsPerPixel);

% Plot images
subplot(2,1,1); colormap(colorMap); image(imageData); axis image; title('Original image'); drawnow;
subplot(2,1,2); colormap(colorMap); image(imageRx); axis image; title(['Received image']); drawnow;
